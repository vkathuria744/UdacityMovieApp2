package quizapp.com.movieappstage1;

public class SettingsActivity {
}
